import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'customer_crud.dart';
import 'customer_provider_data.dart'; // Import your CustomersProvider
import 'customer_datamodel.dart'; // Import your data model

class CustomerHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        FutureProvider<List<Customers>?>(
          create: (context) => CustomersProvider().fetchPosts(),
          initialData: [Customers()],
          catchError: (context, error) {
            // Handle the error here or show an error message to the user
            print('Error in FutureProvider: $error');
            // Return a default value or null
            return [];
          },
        ),
      ],

      child: Scaffold(
        appBar: AppBar(
          title: Text('Customer List'),
        ),
        body: Consumer<List<Customers>>(
          builder: (context, posts, _) {
            if (posts == null) {
              return Center(child: CircularProgressIndicator());
            } else if (posts.isEmpty) {
              return Center(child: Text('No data available'));
            } else {

              return FutureBuilder(
                future: Provider.of<CustomersProvider>(context,listen: false).fetchPosts(),
                builder: (context, snapshot) =>
                 Container(
                   child:ListView.builder(
                     itemCount: null,
                     itemBuilder: (context, index) {
                       var customers = posts[index]?.items;

                       if (customers != null && customers.isNotEmpty && index < customers.length) {
                         return Card(
                           margin: EdgeInsets.all(8.0),
                           child: ListTile(
                             title: Text(customers[index].name ?? 'Name not available'),
                             leading: Container(
                               width: 50,
                               child: Text(customers[index].email ?? 'Email not available'),
                             ),
                           ),
                         );
                       } else {
                         // Handle the case when there are no customers or index is out of bounds
                         return Card(
                           margin: EdgeInsets.all(8.0),
                           child: ListTile(
                             title: Text('Name not available'),
                             leading: Container(
                               width: 50,
                               child: Text('Email not available'),
                             ),
                           ),
                         );
                       }
                     },
                   ),
                 )
              );
            }
          },
        ),

        floatingActionButton: FloatingActionButton(
          onPressed: () {
            _handleFloatingActionButton(context);
          },
          tooltip: 'Create Customer',
          child: Icon(Icons.add),
        ),
      ),
    );
  }

  void _handleFloatingActionButton(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => CustomerCrud()));
  }
}
