import 'package:flutter/material.dart';

import 'Dashboard.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Dashboard(),
  ));
}

// final TextEditingController updateNameController = TextEditingController();
// final TextEditingController updateEmailController = TextEditingController();
// final TextEditingController updateContactController = TextEditingController();


// Expanded(
//   child: Consumer<CustomersProvider>(
//     builder: (context, postProvider, _) {
//       List<Customers> posts = postProvider.posts;
//
//       if (posts == null) {
//         return Center(child: CircularProgressIndicator());
//       } else if (posts.isEmpty) {
//         return Center(child: Text('No data available'));
//       } else {
//         return ListView.builder(
//           itemCount: posts.length,
//           itemBuilder: (context, index) {
//             var post = posts[index];
//             return Card(
//               margin: EdgeInsets.all(8.0),
//               child: ListTile(
//                 title: Text(post.title.toString()),
//                 leading: Container(
//                   width: 50,
//                   child: Text(post.body.toString()),
//                 ),
//                 trailing: Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     IconButton(
//                       icon: Icon(Icons.edit),
//                       onPressed: () {
//                         titleController.text = post.title;
//                         bodyController.text = post.body;
//
//                         showDialog(
//                           context: context,
//                           builder: (BuildContext context) {
//                             return AlertDialog(
//                               title: Text('Update Post'),
//                               content: Column(
//                                 children: [
//                                   TextField(
//                                     controller: updateTitleController,
//                                     decoration: InputDecoration(
//                                         labelText: 'Title'),
//                                   ),
//                                   TextField(
//                                     controller: updateBodyController,
//                                     decoration: InputDecoration(
//                                         labelText: 'Body'),
//                                   ),
//                                 ],
//                               ),
//                               actions: [
//                                 TextButton(
//                                   onPressed: () {
//                                     Navigator.pop(context);
//                                   },
//                                   child: Text('Cancel'),
//                                 ),
//                                 TextButton(
//                                   onPressed: () {
//                                     final updatedPost = Post(
//                                       userId: post.userId,
//                                       id: post.id,
//                                       title: updateTitleController.text,
//                                       body: updateBodyController.text,
//                                     );
//                                     postProvider
//                                         .updatePost(updatedPost, context);
//
//                                     Navigator.pop(context);
//                                   },
//                                   child: Text('Update'),
//                                 ),
//                               ],
//                             );
//                           },
//                         );
//                       },
//                     ),
//                     IconButton(
//                       icon: Icon(Icons.delete),
//                       onPressed: () {
//                         postProvider.deletePost(post.id, context);
//                       },
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         );
//       }
//     },
//   ),
// ),


// body: Consumer<List<Customers>>(
//   builder: (context, posts, _) {
//     if (posts == null) {
//       return Center(child: CircularProgressIndicator());
//     } else if (posts.isEmpty) {
//       return Center(child: Text('No data available'));
//     } else {
//
//       return FutureBuilder(
//         future: Provider.of<CustomersProvider>(context,listen: false).fetchPosts(),
//         builder: (context, snapshot) =>
//          Container(
//            child:ListView.builder(
//              itemCount: snapshot.length,
//              itemBuilder: (context, index) {
//                var customers = posts[index]?.items;
//
//                if (customers != null && customers.isNotEmpty && index < customers.length) {
//                  return Card(
//                    margin: EdgeInsets.all(8.0),
//                    child: ListTile(
//                      title: Text(customers[index].name ?? 'Name not available'),
//                      leading: Container(
//                        width: 50,
//                        child: Text(customers[index].email ?? 'Email not available'),
//                      ),
//                    ),
//                  );
//                } else {
//                  // Handle the case when there are no customers or index is out of bounds
//                  return Card(
//                    margin: EdgeInsets.all(8.0),
//                    child: ListTile(
//                      title: Text('Name not available'),
//                      leading: Container(
//                        width: 50,
//                        child: Text('Email not available'),
//                      ),
//                    ),
//                  );
//                }
//              },
//            ),
//          )
//       );
//     }
//   },
// ),